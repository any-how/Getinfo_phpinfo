<!DOCTYPE html>
<?php 
header("Content-Security-Policy: default-src 'none'; script-src 'nonce-7add75c88d4e5e579e6435ad72e5231b' 'strict-dynamic';base-uri 'self';style-src 'self';font-src 'self'");
function _httpGet($url=""){
        
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_TIMEOUT, 500);
        // 为保证第三方服务器与微信服务器之间数据传输的安全性，所有微信接口采用https方式调用，必须使用下面2行代码打开ssl安全校验。
        // 如果在部署过程中代码在此处验证失败，请到 http://curl.haxx.se/ca/cacert.pem 下载新的证书判别文件。
        // curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        // curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_URL, $url);

        $res = curl_exec($curl);
        curl_close($curl);

        return $res;
}
?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Note Manager</title>
	<script type="text/javascript" src="./static/jquery.js" nonce=7add75c88d4e5e579e6435ad72e5231b></script>
	<link rel="stylesheet" href="./static/bootstrap.min.css" crossorigin="anonymous">
	<script src="./static/bootstrap.min.js" crossorigin="anonymous" nonce=7add75c88d4e5e579e6435ad72e5231b></script>
	<link rel="stylesheet" type="text/css" href="./static/main.css">
	<script type="text/javascript" nonce=7add75c88d4e5e579e6435ad72e5231b>
		$(document).ready(function(){
			$("#forminput").append(i);
			if(location.search.indexOf("name=") != -1 ){$("#yourname").text(params["name"])};
		})
	</script>
</head>
<body>
	<nav class="navbar navbar-default" role="navigation">
	    <div class="container-fluid">
	    <div class="navbar-header">
	        <a class="navbar-brand" href="#">Note Manager</a>
	    </div>
	    <div>
	        <ul class="nav navbar-nav">
	            <li><a href="#">POST</a></li>
	            <li class="active"><a href="test.php?name=Stranger">VIEW</a></li>
	            <li><a href="#">REPORT</a></li>
	        </ul>
	    </div>
	    </div>
	</nav>
	<form class="form-inline" role="form" id="post-02" action="#" method="get">
	  <h3>View your note:</h3>
	  <div class="form-group" id="forminput">
	  	<input type="text" name="name" value="Stranger" hidden="true">
	    <button type="submit" class="btn btn-primary" id="i">View</button>
	 
	  
	  </div>
	  <h4>Hi <a id="yourname"></a>, this is an awesome note management system</h4>
	  Here is your note content: <pre> xssxssxssxsstest
	 	</pre></form> <script type="text/javascript" nonce=7add75c88d4e5e579e6435ad72e5231b>
		function getQuery(){
			return new URL(location.href).searchParams
		}
		function getAllParams(){
			params = {}
			for (value of getQuery().keys()){
				params[value] = getQuery().get(value);
			}
			return params
		}
		params = getAllParams()
		var i = document.createElement("input");
		i.name = "url";
		i.type = "text";
		i.id = "view_input";
		i.style = "width: 450px;height: 30px"
		if(location.search.indexOf("post=") != -1 ){
			i.value = params["post"];
		}
		else{
			i.placeholder = "input your note's url";
		};
	</script>


</body></html>